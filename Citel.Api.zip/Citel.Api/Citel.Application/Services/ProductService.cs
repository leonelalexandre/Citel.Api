﻿using AutoMapper;
using Citel.Application.Dto;
using Citel.Application.Interface;
using Citel.Domain.Entity;
using Citel.Domain.Interface;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Citel.Api.Repository
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly IMapper _mapper;
        public ProductService(IProductRepository productRepository, IMapper mapper)
        {
            _productRepository = productRepository;
            _mapper = mapper;
        }
        public async Task<bool> AddAsync(ProductPostDto dto)
        {
            var product = _mapper.Map<ProductPostDto, Product>(dto);
            await _productRepository.AddAsync(product);

            return await _productRepository.SaveAllAsync();
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var product = await _productRepository.GetById(id);
            if (product == null)
                return false;

            await _productRepository.DeleteAsync(product);

            return await _productRepository.SaveAllAsync();
        }

        public async Task<bool> EditAsync(ProductPostDto dto)
        {
            var product = _mapper.Map<ProductPostDto, Product>(dto);
            await _productRepository.EditAsync(product);

            return await _productRepository.SaveAllAsync();
        }

        public async Task<IEnumerable<ProductGetDto>> Filter()
        {
            var entity = await _productRepository.Filter();
            var dto = _mapper.Map<IEnumerable<Product>, IEnumerable<ProductGetDto>>(entity);

            return dto;
        }

        public async Task<ProductGetDto> GetById(int id)
        {
            var entity = await _productRepository.GetById(id);
            var dto = _mapper.Map<Product, ProductGetDto>(entity);

            return dto;
        }
    }
}

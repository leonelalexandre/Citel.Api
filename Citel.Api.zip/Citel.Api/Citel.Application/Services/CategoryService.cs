﻿using AutoMapper;
using Citel.Application.Dto;
using Citel.Application.Interface;
using Citel.Domain.Entity;
using Citel.Domain.Interface;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Citel.Api.Repository
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository _categoryRepository;
        private readonly IMapper _mapper;
        
        public CategoryService(ICategoryRepository categoryRepository, IMapper mapper)
        {
            _categoryRepository = categoryRepository;
            _mapper = mapper;
        }
        public async Task<bool> AddAsync(CategoryDto categoryDto)
        {
            var category = _mapper.Map<CategoryDto, Category>(categoryDto);
            await _categoryRepository.AddAsync(category);

            return await _categoryRepository.SaveAllAsync();
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var category = await _categoryRepository.GetById(id);
            if (category == null)
                return false;

            await _categoryRepository.DeleteAsync(category);
            return await _categoryRepository.SaveAllAsync(); ;
        }

        public async Task<bool> EditAsync(CategoryDto categoryDto)
        {
            var category = _mapper.Map<CategoryDto, Category>(categoryDto);
            await _categoryRepository.EditAsync(category);

            return await _categoryRepository.SaveAllAsync();
        }

        public async Task<IEnumerable<CategoryDto>> Filter()
        {   
            var category = await _categoryRepository.Filter();
            var dto = _mapper.Map< IEnumerable<Category>, IEnumerable<CategoryDto> >(category);

            return dto;
        }

        public async Task<CategoryDto> GetById(int id)
        {
            var category = await _categoryRepository.GetById(id);
            var dto = _mapper.Map<Category, CategoryDto>(category);

            return dto;
        }

    }
}

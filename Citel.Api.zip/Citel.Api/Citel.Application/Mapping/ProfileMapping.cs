﻿using AutoMapper;
using Citel.Application.Dto;
using Citel.Domain.Entity;

namespace Citel.Application.Mapping
{
    public class ProfileMapping : Profile
    {
        public ProfileMapping()
        {
            CreateMap<Category, CategoryDto>().ReverseMap();
            CreateMap<Product, ProductPostDto>().ReverseMap();
            CreateMap<Product, ProductGetDto>().ReverseMap();
        }
    }
}

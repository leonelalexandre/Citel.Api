﻿using Citel.Application.Dto;
using Citel.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Citel.Application.Interface
{
    public interface IProductService
    {
        Task<bool> AddAsync(ProductPostDto product);
        Task <bool> EditAsync(ProductPostDto product);
        Task<bool> DeleteAsync(int id);
        Task<ProductGetDto> GetById(int id);
        Task<IEnumerable<ProductGetDto>> Filter();
    }
}

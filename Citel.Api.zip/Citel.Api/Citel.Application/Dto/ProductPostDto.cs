﻿namespace Citel.Application.Dto
{
    public class ProductPostDto
    {
        public int Id { get; set; }
        public string Description { get; set; }

        public int IdCategory { get; set; }

    }
}
